package com.zensar.bean.ui;

import javax.persistence.EntityManager;

import com.zensar.bean.Address;
import com.zensar.bean.BankAccount;

import com.zensar.bean.Employee;
import com.zensar.bean.Skill;
import com.zensar.bean.util.JPAUtil;


public class Main {
	public static void insertTesting() {
		//write code here to persist employee object
		EntityManager em = JPAUtil.createEntityManager("PU");
		Employee emp=new Employee("subahsh",20000);
		Address add=new Address("pune","456720");
		BankAccount account=new BankAccount(12,"55455678");
		Skill skill=new Skill("java", 1);
		emp.getAddress();
		emp.getAccount();
		emp.getSkillList();
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
		JPAUtil.shutDown();
	}
	public static void loadTesting() {
		//write code here to load employee object
		EntityManager em = JPAUtil.createEntityManager("PU");
		Employee emp = em.find(Employee.class, 1);
		System.out.println(emp);
		JPAUtil.shutDown();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		insertTesting();

	}

}

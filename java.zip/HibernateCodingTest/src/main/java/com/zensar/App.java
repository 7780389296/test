package com.zensar;

public class App {
	public static void loadTesting() {
		//write code here to load employee object
	}
	public static void insertTesting() {
		//write code here to persist employee object
	}
  public static void main(String[] args) {
    
  }
}
